//Variabili utili
    id=0;
    end=document.getElementById("End");
    icon=document.getElementById("shell_icon");
    const weather="2b39a566db0bcd7071503ce69c2b008c";
    let shellCounter=0;
    let arrayShell=[];
    const intro= new Audio("assets/The Hub Intro - Sound Effect (Free).mp3");
    let currentColor=  "#000000";
    //Funzione creazione shell


    function createShell (){
       let shell= document.createElement("div");
        shell.setAttribute("class", "shell");
        shell.setAttribute("id", "sh_"+id++);
        document.body.appendChild(shell);
        //Header
        let header=document.createElement("div");
        header.setAttribute("class","header");
        //Zone di resize
        let down_left=document.createElement("button");
        let down_right=document.createElement("button");
        let up_left=document.createElement("button");
        let up_right=document.createElement("button");
        down_left.setAttribute("class","resize down_left");
        down_right.setAttribute("class","resize down_right");
        up_left.setAttribute("class","resize up_left");
        up_right.setAttribute("class","resize up_right");
        shell.appendChild(header);
        header.appendChild(up_left);
        header.appendChild(up_right);
        //Icona bg
        let icon_bg=document.createElement("button");
         icon_bg.setAttribute("class","icon_end");
         end.appendChild(icon_bg)
        //Icone
        let close=document.createElement("button");
        close.setAttribute("class","close_button");
        header.appendChild(close);
        let minimize=document.createElement("button");
        minimize.setAttribute("class","minimize_button");
        header.appendChild(minimize);
        let full_screen=document.createElement("button");
        full_screen.setAttribute("class","maximize_button");
        header.appendChild(full_screen);
        //Corpo della shell dove scrivere
        let  bodyShell=document.createElement("div");
        bodyShell.setAttribute("class","Body_shell");
        shell.appendChild(bodyShell);
       const row = createShellRow();    
        bodyShell.appendChild(row.text);
        bodyShell.appendChild(down_left);
        bodyShell.appendChild(down_right);
       
        //Eventi delle Icone di chiusura,minimize,full_screen,Icon_bg
        guiBtn(close,minimize,icon_bg,full_screen,shell);
        //Resize
        resize(down_right,shell,"down_right");
        resize(down_left,shell,"down_left");
        resize(up_left,shell,"up_left");
        resize(up_right,shell,"up_right");
        //Aggiunge la riga e controlla i comandi
        addnewRow(row.text,bodyShell);
         row.editable.focus();
        //Drag
        drag(header,shell);
        //Il focus
        bodyShell.addEventListener('click',()=>{focusShell(shell.id)});
         header.addEventListener('click',()=>{focusShell(shell.id)});
            return shell;
    }



    //Evento creazione della shell
    icon.addEventListener('click',()=>{
        console.log("creazione shell");
        arrayShell[shellCounter]=createShell();
        shellCounter++;
        console.log("il numero di shell è :",shellCounter,"shell aggiunta",arrayShell[shellCounter-1].id);
    })

    //Evento aggiunta nuova riga e controllo comandi
    function addnewRow(text, bodyShell) {
        text.addEventListener('keydown', (event) => {
            if (event.key == "Enter") {
                let check = text.querySelector('.editable').textContent.trim();
                let words = check.split(" ");
                let firstWord = words[0];
                let rest = words.slice(1).join(" ");
                text.querySelector('.editable').setAttribute("contenteditable", "false");
                let result = document.createElement("div");
                result.setAttribute("class", "output");
                // 1 comando
                if (firstWord === "echo") {
                    result.textContent = rest;
                    bodyShell.appendChild(result);
                    const row = createShellRow();
                    bodyShell.appendChild(row.text);
                    row.editable.focus();
                    addnewRow(row.text, bodyShell);
                }
                // 2 comando
                else if (firstWord === "weather") {
                    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${rest}&appid=${weather}&units=metric&lang=it`)
                        .then(res => res.json())
                        .then(dati => {
                            let temp = dati.main.temp;
                            let descr = dati.weather[0].description;
                            result.textContent = `A ${rest}, ci sono ${temp}, ${descr}`;
                            bodyShell.appendChild(result);
                            const row = createShellRow();
                            bodyShell.appendChild(row.text);
                            row.editable.focus();
                            addnewRow(row.text, bodyShell);
                        })
                        .catch(err => {
                            console.error("Errore", err);
                            result.textContent = "Errore nella richiesta";
                            bodyShell.appendChild(result);
                            const row = createShellRow();
                            bodyShell.appendChild(row.text);
                            row.editable.focus();
                            addnewRow(row.text, bodyShell);
                        });
                }
                //3 Comando
                else if (firstWord === "anime") {
                    fetch(`https://api.jikan.moe/v4/anime?q=${rest}`)
                        .then(res => res.json())
                        .then(dati => {
                            let temp = dati.data[0];
                            let resp = "title: " + temp.title + " plot: " + temp.synopsis + " status: " + temp.status + " episode: " + temp.episodes;
                            result.textContent = resp;
                            bodyShell.appendChild(result);
                            const row = createShellRow();
                            bodyShell.appendChild(row.text);
                            row.editable.focus();
                            addnewRow(row.text, bodyShell);
                        })
                        .catch(err => {
                            console.error("Errore", err);
                            result.textContent = "Errore nella richiesta";
                            bodyShell.appendChild(result);
                            const row = createShellRow();
                            bodyShell.appendChild(row.text);
                            row.editable.focus();
                            addnewRow(row.text, bodyShell);
                        });
                }
                //Easter egg
                else if (firstWord === "ph") {
                    intro.play();
                    result.textContent = "Riproduzione in corso...";
                    bodyShell.appendChild(result);
                    const row = createShellRow();
                    bodyShell.appendChild(row.text);
                    row.editable.focus();
                    addnewRow(row.text, bodyShell);
                }
                //Metodo a piacere
                else if (firstWord === "paint") {
                    let tela = document.createElement("div");
                    let headi = document.createElement("div");
                    let surface = document.createElement("canvas");
                    let close = document.createElement("button");
                    let eraser = document.createElement("button");
                    let fill = document.createElement("button");
                    eraser.setAttribute("class", "gomma");
                    headi.appendChild(eraser);
                    fill.setAttribute("class", "fill");
                    headi.appendChild(fill);
                    close.setAttribute("class", "close_buttonP");
                    headi.appendChild(close);
                    close.textContent = "X";
                    const colori = ["#000000", "#FF0000", "#00FF00", "#0000FF", "#FFFF00", "#FF00FF", "#00FFFF"];
                    colori.forEach(col => {
                        let coloreBtn = document.createElement("button");
                        coloreBtn.setAttribute("class", "colore");
                        coloreBtn.style.backgroundColor = col;
                        headi.appendChild(coloreBtn);
                        coloreBtn.addEventListener('click', () => {
                            currentColor = col;
                        });
                    });
                    surface.setAttribute("class", "disegno");
                    tela.setAttribute("class", "contenitore");
                    headi.setAttribute("class", "header");
                    tela.appendChild(headi);
                    tela.appendChild(surface);
                    document.body.appendChild(tela);
                    surface.setAttribute("width", tela.clientWidth);
                    surface.setAttribute("height", tela.clientHeight);
                    fill.addEventListener('click', () => {
                        surface.style.backgroundColor = currentColor;
                    });
                    eraser.addEventListener('click', () => {
                        currentColor = getComputedStyle(surface).backgroundColor;
                        console.log(getComputedStyle(surface).backgroundColor);
                    });
                    close.addEventListener('click', () => {
                        tela.remove();
                    });
                    draw(surface);
                    const row = createShellRow();
                    bodyShell.appendChild(row.text);
                    row.editable.focus();
                    addnewRow(row.text, bodyShell);
                }
                else {
                    result.textContent = "Comando non riconosciuto";
                    bodyShell.appendChild(result);
                    const row = createShellRow();
                    bodyShell.appendChild(row.text);
                    row.editable.focus();
                    addnewRow(row.text, bodyShell);
                }
            }
        });
            
    
}
//Funzione resize
function resize(event, subject, dir) {
    event.addEventListener('mousedown', (e)=> {
        let startX = e.clientX;
        let startY = e.clientY;
        let startWidth = subject.offsetWidth;
        let startHeight = subject.offsetHeight;
        let startLeft = subject.offsetLeft;
        let startTop = subject.offsetTop;

        function onMouseMove(e) {
            if (dir === "down_right") {
                subject.style.width = (startWidth + (e.clientX - startX)) + "px";
                subject.style.height = (startHeight + (e.clientY - startY)) + "px";
            } else if (dir === "down_left") {
                subject.style.width = (startWidth - (e.clientX - startX)) + "px";
                subject.style.left = (startLeft + (e.clientX - startX)) + "px";
                subject.style.height = (startHeight + (e.clientY - startY)) + "px";
            } else if (dir === "up_right") {
                subject.style.width = (startWidth + (e.clientX - startX)) + "px";
                subject.style.height = (startHeight - (e.clientY - startY)) + "px";
                subject.style.top = (startTop + (e.clientY - startY)) + "px";
            } else if (dir === "up_left") {
                subject.style.width = (startWidth - (e.clientX - startX)) + "px";
                subject.style.left = (startLeft + (e.clientX - startX)) + "px";
                subject.style.height = (startHeight - (e.clientY - startY)) + "px";
                subject.style.top = (startTop + (e.clientY - startY)) + "px";
            }
        }
        function onMouseUp() {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        }
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    });
}
//Funzione per il drag
function drag(event,subject){
    event.addEventListener('mousedown',function(e){
        if (e.target.tagName === "BUTTON") return;
        let posX=e.clientX;
        let posY=e.clientY;
        let subTop=subject.offsetTop;
        let subLeft=subject.offsetLeft;
        function onMouseMove(e){
            subject.style.left=(subLeft+(e.clientX-posX))+"px";
            subject.style.top=(subTop+(e.clientY-posY))+"px";
        }
        function onMouseUp(){
            document.removeEventListener('mousemove',onMouseMove);
            document.removeEventListener('mouseup',onMouseUp);
        }
        document.addEventListener('mousemove',onMouseMove);
        document.addEventListener('mouseup',onMouseUp);
    });
}
//Funzione per il focus
function focusShell(id){
    console.log("funzione focus avviata");
    for(var index in arrayShell){
        if(arrayShell[index].id===id){
            arrayShell[index].style.zIndex=shellCounter;
        }
        else{
            if(arrayShell[index].style.zIndex==shellCounter)arrayShell[index].style.zIndex-=1;
        }
    }
}
function draw(canva){
    let disegno=false;
    let c=canva.getContext("2d");
    canva.addEventListener('mousedown',(e)=>{
        disegno=true;
        c.beginPath();
        c.strokeStyle=currentColor;
        console.log("disegno start");
    });
    canva.addEventListener('mousemove',(e)=>{
        if(disegno){
            c.lineTo(e.offsetX,e.offsetY);
            c.stroke();
            console.log("disegnando");
        }
    })
    canva.addEventListener("mouseup", () => {
    disegno = false;
    console.log("disegnano end");
    });

    canva.addEventListener("mouseleave", () => {
    disegno = false;
        console.log("disegnano end");
    });
}
function createShellRow() {
    const text = document.createElement("div");
    text.setAttribute("class", "Text");
    const before = document.createElement("span");
    before.setAttribute("class", "before");
    before.textContent = "root@localhost:~$ ";
    const editable = document.createElement("span");
    editable.setAttribute("class", "editable");
    editable.setAttribute("contenteditable", "true");
    text.appendChild(before);
    text.appendChild(editable);
    return { text, before, editable };
}

function guiBtn(close,minimize,icon_bg,full_screen,shell){
        close.addEventListener('click',()=>{
            shell.remove();
            icon_bg.remove();
            shellCounter--;
        })
        minimize.addEventListener('click',()=>{
            shell.style.display="none";
            shellCounter--;
            console.log("il numero di shell è",shellCounter);
        })
        icon_bg.addEventListener('click',()=>{
                if(shell.style.display=="none"){
                    shell.style.display="block";
                    shellCounter++;
                    focusShell(shell.id);
                console.log("il numero di shell è",shellCounter);
                }
                else{
                    shell.style.display="none";
                    shellCounter--;
                    console.log("il numero di shell è",shellCounter);
                }
        })
        full_screen.addEventListener('click',()=>{
                let shellWidth=shell.offsetWidth;
                let windowWidth=window.innerWidth;
                let percentW= (shellWidth/windowWidth)*100;
                let shellHeigth=shell.offsetHeight;
                let windowHeigth=window.innerHeight;
                let percentH= (shellHeigth/windowHeigth)*100;
                if(percentW<100||percentH<100){
                    shell.style.width="100vw";
                    shell.style.height="100vh";
                    shell.style.left="0";
                    shell.style.top="0";
                }
                else{
                    shell.style.width="50vw";
                    shell.style.height="40vh";
                    console.log("Clicco per decrementare");
                    shell.style.left="400px";
                    shell.style.top="100px";
                }
        })
    }